# Brain Tumor Detection
[![made-with-python](https://img.shields.io/badge/Made%20with-Python-1f425f.svg)](https://www.python.org/)

CNN model that would classify if the Brain has a tumor or not base on an MRI scan.
<p align="center">
<img src="https://github.com/AbderrahimAl/Brain_Tumor_Detection/blob/main/brain_tumor_dataset/yes/Y104.jpg">
</p>
